# Warehouse
Second TPSEE project of 2019: automatic warehouse
